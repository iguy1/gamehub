"use client"

import { useEffect, useRef, useState } from "react"
import { Game } from "@/lib/game"

export default function GameCanvas() {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [game, setGame] = useState<Game | null>(null)
  const [isGameStarted, setIsGameStarted] = useState(false)

  useEffect(() => {
    if (!canvasRef.current) return

    const canvas = canvasRef.current
    const newGame = new Game(canvas)
    setGame(newGame)

    return () => {
      newGame.destroy()
    }
  }, [])

  const handleStartGame = () => {
    if (game) {
      game.start()
      setIsGameStarted(true)
    }
  }

  return (
    <>
      <canvas ref={canvasRef} className="absolute inset-0 h-full w-full" width={1280} height={720} />
      {!isGameStarted && (
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/70">
          <h2 className="mb-6 text-3xl font-bold text-white">Battle Royale</h2>
          <button
            onClick={handleStartGame}
            className="rounded-lg bg-red-600 px-8 py-3 font-bold text-white transition-colors hover:bg-red-700"
          >
            START GAME
          </button>
        </div>
      )}
    </>
  )
}

