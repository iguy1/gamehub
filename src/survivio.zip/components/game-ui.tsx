"use client"

import { useEffect, useState } from "react"
import { Heart, PenIcon as Gun, Shield, Users } from "lucide-react"

export default function GameUI() {
  const [health, setHealth] = useState(100)
  const [ammo, setAmmo] = useState(30)
  const [armor, setArmor] = useState(0)
  const [playersLeft, setPlayersLeft] = useState(50)

  // This would normally be connected to the game state
  useEffect(() => {
    const interval = setInterval(() => {
      // Simulate game events
      if (Math.random() < 0.1) {
        setHealth((prev) => Math.max(0, prev - Math.floor(Math.random() * 10)))
      }
      if (Math.random() < 0.2) {
        setAmmo((prev) => Math.max(0, prev - 1))
      }
      if (Math.random() < 0.05) {
        setPlayersLeft((prev) => Math.max(1, prev - 1))
      }
    }, 2000)

    return () => clearInterval(interval)
  }, [])

  return (
    <div className="pointer-events-none absolute inset-x-0 bottom-0 p-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-6">
          <div className="flex items-center gap-2">
            <Heart className="h-6 w-6 text-red-500" fill="red" />
            <div className="h-4 w-32 rounded-full bg-gray-800">
              <div className="h-full rounded-full bg-red-500" style={{ width: `${health}%` }} />
            </div>
          </div>

          <div className="flex items-center gap-2">
            <Shield className="h-6 w-6 text-blue-400" />
            <div className="h-4 w-24 rounded-full bg-gray-800">
              <div className="h-full rounded-full bg-blue-400" style={{ width: `${armor}%` }} />
            </div>
          </div>

          <div className="flex items-center gap-2 rounded-lg bg-gray-800 px-3 py-1">
            <Gun className="h-5 w-5 text-yellow-400" />
            <span className="font-mono text-lg font-bold text-white">{ammo}</span>
          </div>
        </div>

        <div className="flex items-center gap-2 rounded-lg bg-gray-800 px-3 py-1">
          <Users className="h-5 w-5 text-white" />
          <span className="font-mono text-lg font-bold text-white">{playersLeft}</span>
        </div>
      </div>
    </div>
  )
}

