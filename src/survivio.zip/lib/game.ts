export class Vector2 {
  constructor(
    public x: number,
    public y: number,
  ) {}

  add(other: Vector2): Vector2 {
    return new Vector2(this.x + other.x, this.y + other.y)
  }

  subtract(other: Vector2): Vector2 {
    return new Vector2(this.x - other.x, this.y - other.y)
  }

  multiply(scalar: number): Vector2 {
    return new Vector2(this.x * scalar, this.y * scalar)
  }

  normalize(): Vector2 {
    const length = Math.sqrt(this.x * this.x + this.y * this.y)
    if (length === 0) return new Vector2(0, 0)
    return new Vector2(this.x / length, this.y / length)
  }

  length(): number {
    return Math.sqrt(this.x * this.x + this.y * this.y)
  }
}

export class Entity {
  position: Vector2
  velocity: Vector2
  size: number
  color: string

  constructor(x: number, y: number, size: number, color: string) {
    this.position = new Vector2(x, y)
    this.velocity = new Vector2(0, 0)
    this.size = size
    this.color = color
  }

  update(deltaTime: number): void {
    this.position = this.position.add(this.velocity.multiply(deltaTime))
  }

  draw(ctx: CanvasRenderingContext2D): void {
    ctx.fillStyle = this.color
    ctx.beginPath()
    ctx.arc(this.position.x, this.position.y, this.size, 0, Math.PI * 2)
    ctx.fill()
  }

  collidesWith(other: Entity): boolean {
    const distance = this.position.subtract(other.position).length()
    return distance < this.size + other.size
  }
}

export class Player extends Entity {
  health = 100
  armor = 0
  rotation = 0
  weapon: Weapon | null = null
  isBot: boolean

  constructor(x: number, y: number, isBot = false) {
    super(x, y, 20, isBot ? "#ff4d4d" : "#ffcc00")
    this.isBot = isBot
    if (isBot) {
      this.weapon = new Weapon("Pistol", 10, 15, 500)
    }
  }

  update(deltaTime: number): void {
    super.update(deltaTime)

    // Bot AI logic
    if (this.isBot && Math.random() < 0.02) {
      this.velocity = new Vector2(Math.random() * 200 - 100, Math.random() * 200 - 100)
      this.rotation = Math.random() * Math.PI * 2
    }
  }

  draw(ctx: CanvasRenderingContext2D): void {
    // Draw player body
    ctx.fillStyle = this.color
    ctx.beginPath()
    ctx.arc(this.position.x, this.position.y, this.size, 0, Math.PI * 2)
    ctx.fill()

    // Draw direction indicator
    ctx.fillStyle = "#000"
    const dirX = this.position.x + Math.cos(this.rotation) * this.size
    const dirY = this.position.y + Math.sin(this.rotation) * this.size
    ctx.beginPath()
    ctx.arc(dirX, dirY, this.size / 3, 0, Math.PI * 2)
    ctx.fill()

    // Draw weapon if player has one
    if (this.weapon) {
      ctx.save()
      ctx.translate(this.position.x, this.position.y)
      ctx.rotate(this.rotation)
      ctx.fillStyle = "#555"
      ctx.fillRect(this.size - 5, -5, this.size, 10)
      ctx.restore()
    }
  }

  takeDamage(amount: number): void {
    if (this.armor > 0) {
      const armorAbsorb = Math.min(this.armor, amount * 0.5)
      this.armor -= armorAbsorb
      amount -= armorAbsorb
    }
    this.health -= amount
  }

  shoot(): Bullet | null {
    if (!this.weapon || !this.weapon.canShoot()) return null

    const bulletSpeed = 500
    const bulletDirection = new Vector2(Math.cos(this.rotation), Math.sin(this.rotation))

    const bulletPosition = this.position.add(bulletDirection.multiply(this.size + 10))

    const bullet = new Bullet(bulletPosition.x, bulletPosition.y, bulletDirection, bulletSpeed, this.weapon.damage)

    this.weapon.shoot()
    return bullet
  }
}

export class Bullet extends Entity {
  direction: Vector2
  speed: number
  damage: number
  lifetime = 2 // Seconds before bullet disappears

  constructor(x: number, y: number, direction: Vector2, speed: number, damage: number) {
    super(x, y, 3, "#fff")
    this.direction = direction
    this.speed = speed
    this.damage = damage
    this.velocity = direction.multiply(speed)
  }

  update(deltaTime: number): void {
    super.update(deltaTime)
    this.lifetime -= deltaTime
  }
}

export class Weapon {
  name: string
  damage: number
  ammo: number
  fireRate: number // milliseconds between shots
  lastShotTime = 0

  constructor(name: string, damage: number, ammo: number, fireRate: number) {
    this.name = name
    this.damage = damage
    this.ammo = ammo
    this.fireRate = fireRate
  }

  canShoot(): boolean {
    if (this.ammo <= 0) return false
    const now = Date.now()
    return now - this.lastShotTime >= this.fireRate
  }

  shoot(): void {
    if (this.canShoot()) {
      this.ammo--
      this.lastShotTime = Date.now()
    }
  }
}

export class Obstacle extends Entity {
  constructor(x: number, y: number, size: number) {
    super(x, y, size, "#555")
  }

  draw(ctx: CanvasRenderingContext2D): void {
    ctx.fillStyle = this.color
    ctx.fillRect(this.position.x - this.size, this.position.y - this.size, this.size * 2, this.size * 2)
  }
}

export class Item extends Entity {
  type: "health" | "ammo" | "armor" | "weapon"
  value: number
  weaponType?: string

  constructor(x: number, y: number, type: "health" | "ammo" | "armor" | "weapon", value: number, weaponType?: string) {
    let color = "#fff"
    switch (type) {
      case "health":
        color = "#ff4d4d"
        break
      case "ammo":
        color = "#ffcc00"
        break
      case "armor":
        color = "#4d94ff"
        break
      case "weapon":
        color = "#9966ff"
        break
    }
    super(x, y, 10, color)
    this.type = type
    this.value = value
    this.weaponType = weaponType
  }

  draw(ctx: CanvasRenderingContext2D): void {
    ctx.fillStyle = this.color
    ctx.beginPath()

    if (this.type === "health") {
      // Draw a cross for health
      ctx.fillRect(this.position.x - 8, this.position.y - 3, 16, 6)
      ctx.fillRect(this.position.x - 3, this.position.y - 8, 6, 16)
    } else if (this.type === "ammo") {
      // Draw a bullet for ammo
      ctx.arc(this.position.x, this.position.y, this.size, 0, Math.PI * 2)
    } else if (this.type === "armor") {
      // Draw a shield for armor
      ctx.beginPath()
      ctx.moveTo(this.position.x, this.position.y - 10)
      ctx.lineTo(this.position.x + 8, this.position.y - 5)
      ctx.lineTo(this.position.x + 8, this.position.y + 5)
      ctx.lineTo(this.position.x, this.position.y + 10)
      ctx.lineTo(this.position.x - 8, this.position.y + 5)
      ctx.lineTo(this.position.x - 8, this.position.y - 5)
      ctx.closePath()
    } else if (this.type === "weapon") {
      // Draw a gun for weapon
      ctx.fillRect(this.position.x - 8, this.position.y - 3, 16, 6)
      ctx.fillRect(this.position.x + 4, this.position.y - 8, 4, 16)
    }

    ctx.fill()
  }
}

export class Game {
  canvas: HTMLCanvasElement
  ctx: CanvasRenderingContext2D
  player: Player
  bots: Player[] = []
  bullets: Bullet[] = []
  obstacles: Obstacle[] = []
  items: Item[] = []
  keys: { [key: string]: boolean } = {}
  mousePosition: Vector2 = new Vector2(0, 0)
  isMouseDown = false
  lastFrameTime = 0
  gameLoop: number | null = null
  mapSize = 2000
  camera: Vector2 = new Vector2(0, 0)
  isGameOver = false

  constructor(canvas: HTMLCanvasElement) {
    this.canvas = canvas
    this.ctx = canvas.getContext("2d")!

    // Create player in the center of the map
    this.player = new Player(this.mapSize / 2, this.mapSize / 2)
    this.player.weapon = new Weapon("Pistol", 10, 30, 500)

    // Set up event listeners
    window.addEventListener("keydown", this.handleKeyDown)
    window.addEventListener("keyup", this.handleKeyUp)
    canvas.addEventListener("mousemove", this.handleMouseMove)
    canvas.addEventListener("mousedown", this.handleMouseDown)
    canvas.addEventListener("mouseup", this.handleMouseUp)
  }

  start(): void {
    // Generate map
    this.generateMap()

    // Start game loop
    this.lastFrameTime = performance.now()
    this.gameLoop = requestAnimationFrame(this.update)
  }

  generateMap(): void {
    // Generate obstacles
    for (let i = 0; i < 50; i++) {
      const x = Math.random() * this.mapSize
      const y = Math.random() * this.mapSize
      const size = 20 + Math.random() * 30
      this.obstacles.push(new Obstacle(x, y, size))
    }

    // Generate items
    for (let i = 0; i < 30; i++) {
      const x = Math.random() * this.mapSize
      const y = Math.random() * this.mapSize
      const types: ("health" | "ammo" | "armor" | "weapon")[] = ["health", "ammo", "armor", "weapon"]
      const type = types[Math.floor(Math.random() * types.length)]
      let value = 0
      let weaponType

      switch (type) {
        case "health":
          value = 25 + Math.floor(Math.random() * 25)
          break
        case "ammo":
          value = 10 + Math.floor(Math.random() * 20)
          break
        case "armor":
          value = 25 + Math.floor(Math.random() * 25)
          break
        case "weapon":
          value = 1
          const weapons = ["Pistol", "Shotgun", "Rifle", "Sniper"]
          weaponType = weapons[Math.floor(Math.random() * weapons.length)]
          break
      }

      this.items.push(new Item(x, y, type, value, weaponType))
    }

    // Generate bots
    for (let i = 0; i < 10; i++) {
      let x, y
      let validPosition = false

      // Make sure bots don't spawn too close to the player
      while (!validPosition) {
        x = Math.random() * this.mapSize
        y = Math.random() * this.mapSize
        const distToPlayer = Math.sqrt(
          Math.pow(x - this.player.position.x, 2) + Math.pow(y - this.player.position.y, 2),
        )
        if (distToPlayer > 300) {
          validPosition = true
        }
      }

      this.bots.push(new Player(x!, y!, true))
    }
  }

  update = (timestamp: number): void => {
    if (this.isGameOver) return

    const deltaTime = (timestamp - this.lastFrameTime) / 1000
    this.lastFrameTime = timestamp

    // Update player
    this.updatePlayerMovement(deltaTime)
    this.player.update(deltaTime)

    // Update camera to follow player
    this.camera.x = this.player.position.x - this.canvas.width / 2
    this.camera.y = this.player.position.y - this.canvas.height / 2

    // Update bots
    for (let i = this.bots.length - 1; i >= 0; i--) {
      const bot = this.bots[i]
      bot.update(deltaTime)

      // Bot shooting logic
      if (bot.weapon && Math.random() < 0.02 && this.getDistanceToPlayer(bot) < 300) {
        const bullet = bot.shoot()
        if (bullet) this.bullets.push(bullet)
      }

      // Check if bot is dead
      if (bot.health <= 0) {
        this.bots.splice(i, 1)
      }
    }

    // Update bullets
    for (let i = this.bullets.length - 1; i >= 0; i--) {
      const bullet = this.bullets[i]
      bullet.update(deltaTime)

      // Check bullet collisions with obstacles
      for (const obstacle of this.obstacles) {
        if (bullet.collidesWith(obstacle)) {
          this.bullets.splice(i, 1)
          break
        }
      }

      // Check bullet collisions with player
      if (bullet.collidesWith(this.player)) {
        this.player.takeDamage(bullet.damage)
        this.bullets.splice(i, 1)
        continue
      }

      // Check bullet collisions with bots
      for (const bot of this.bots) {
        if (bullet.collidesWith(bot)) {
          bot.takeDamage(bullet.damage)
          this.bullets.splice(i, 1)
          break
        }
      }

      // Remove bullets that have expired
      if (bullet.lifetime <= 0) {
        this.bullets.splice(i, 1)
      }
    }

    // Check player collisions with items
    for (let i = this.items.length - 1; i >= 0; i--) {
      const item = this.items[i]
      if (this.player.collidesWith(item)) {
        this.collectItem(item)
        this.items.splice(i, 1)
      }
    }

    // Check if player is dead
    if (this.player.health <= 0) {
      this.gameOver(false)
      return
    }

    // Check if player won
    if (this.bots.length === 0) {
      this.gameOver(true)
      return
    }

    // Draw everything
    this.draw()

    // Continue game loop
    this.gameLoop = requestAnimationFrame(this.update)
  }

  updatePlayerMovement(deltaTime: number): void {
    // Reset velocity
    this.player.velocity = new Vector2(0, 0)

    // Calculate movement direction
    const speed = 200
    if (this.keys["w"] || this.keys["ArrowUp"]) {
      this.player.velocity.y -= speed
    }
    if (this.keys["s"] || this.keys["ArrowDown"]) {
      this.player.velocity.y += speed
    }
    if (this.keys["a"] || this.keys["ArrowLeft"]) {
      this.player.velocity.x -= speed
    }
    if (this.keys["d"] || this.keys["ArrowRight"]) {
      this.player.velocity.x += speed
    }

    // Calculate rotation based on mouse position
    const canvasRect = this.canvas.getBoundingClientRect()
    const mouseWorldPos = new Vector2(this.mousePosition.x + this.camera.x, this.mousePosition.y + this.camera.y)
    const direction = mouseWorldPos.subtract(this.player.position)
    this.player.rotation = Math.atan2(direction.y, direction.x)

    // Handle shooting
    if (this.isMouseDown && this.player.weapon) {
      const bullet = this.player.shoot()
      if (bullet) this.bullets.push(bullet)
    }

    // Handle collisions with obstacles
    for (const obstacle of this.obstacles) {
      const nextPos = this.player.position.add(this.player.velocity.multiply(deltaTime))
      const dx = nextPos.x - obstacle.position.x
      const dy = nextPos.y - obstacle.position.y
      const distance = Math.sqrt(dx * dx + dy * dy)
      const minDistance = this.player.size + obstacle.size

      if (distance < minDistance) {
        // Calculate push direction
        const pushDirection = new Vector2(dx, dy).normalize()
        const pushAmount = minDistance - distance

        // Push player away from obstacle
        this.player.position = this.player.position.add(pushDirection.multiply(pushAmount))
      }
    }

    // Keep player within map bounds
    const nextPos = this.player.position.add(this.player.velocity.multiply(deltaTime))
    if (nextPos.x < this.player.size) {
      this.player.position.x = this.player.size
      this.player.velocity.x = 0
    } else if (nextPos.x > this.mapSize - this.player.size) {
      this.player.position.x = this.mapSize - this.player.size
      this.player.velocity.x = 0
    }

    if (nextPos.y < this.player.size) {
      this.player.position.y = this.player.size
      this.player.velocity.y = 0
    } else if (nextPos.y > this.mapSize - this.player.size) {
      this.player.position.y = this.mapSize - this.player.size
      this.player.velocity.y = 0
    }
  }

  draw(): void {
    // Clear canvas
    this.ctx.fillStyle = "#4a8c3f" // Green background like grass
    this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height)

    // Draw grid
    this.ctx.strokeStyle = "#5a9c4f"
    this.ctx.lineWidth = 1
    const gridSize = 50
    const startX = -this.camera.x % gridSize
    const startY = -this.camera.y % gridSize

    for (let x = startX; x < this.canvas.width; x += gridSize) {
      this.ctx.beginPath()
      this.ctx.moveTo(x, 0)
      this.ctx.lineTo(x, this.canvas.height)
      this.ctx.stroke()
    }

    for (let y = startY; y < this.canvas.height; y += gridSize) {
      this.ctx.beginPath()
      this.ctx.moveTo(0, y)
      this.ctx.lineTo(this.canvas.width, y)
      this.ctx.stroke()
    }

    // Save context state
    this.ctx.save()

    // Translate to camera position
    this.ctx.translate(-this.camera.x, -this.camera.y)

    // Draw map boundary
    this.ctx.strokeStyle = "#ff0000"
    this.ctx.lineWidth = 5
    this.ctx.strokeRect(0, 0, this.mapSize, this.mapSize)

    // Draw obstacles
    for (const obstacle of this.obstacles) {
      obstacle.draw(this.ctx)
    }

    // Draw items
    for (const item of this.items) {
      item.draw(this.ctx)
    }

    // Draw bullets
    for (const bullet of this.bullets) {
      bullet.draw(this.ctx)
    }

    // Draw bots
    for (const bot of this.bots) {
      bot.draw(this.ctx)
    }

    // Draw player
    this.player.draw(this.ctx)

    // Restore context state
    this.ctx.restore()

    // Draw minimap
    this.drawMinimap()

    // Draw player stats
    this.drawPlayerStats()
  }

  drawMinimap(): void {
    const minimapSize = 150
    const minimapX = this.canvas.width - minimapSize - 10
    const minimapY = 10
    const minimapScale = minimapSize / this.mapSize

    // Draw minimap background
    this.ctx.fillStyle = "rgba(0, 0, 0, 0.5)"
    this.ctx.fillRect(minimapX, minimapY, minimapSize, minimapSize)

    // Draw player on minimap
    this.ctx.fillStyle = "#ffcc00"
    this.ctx.beginPath()
    this.ctx.arc(
      minimapX + this.player.position.x * minimapScale,
      minimapY + this.player.position.y * minimapScale,
      4,
      0,
      Math.PI * 2,
    )
    this.ctx.fill()

    // Draw bots on minimap
    this.ctx.fillStyle = "#ff4d4d"
    for (const bot of this.bots) {
      this.ctx.beginPath()
      this.ctx.arc(
        minimapX + bot.position.x * minimapScale,
        minimapY + bot.position.y * minimapScale,
        3,
        0,
        Math.PI * 2,
      )
      this.ctx.fill()
    }

    // Draw obstacles on minimap
    this.ctx.fillStyle = "#555"
    for (const obstacle of this.obstacles) {
      this.ctx.fillRect(
        minimapX + (obstacle.position.x - obstacle.size) * minimapScale,
        minimapY + (obstacle.position.y - obstacle.size) * minimapScale,
        obstacle.size * 2 * minimapScale,
        obstacle.size * 2 * minimapScale,
      )
    }

    // Draw items on minimap
    this.ctx.fillStyle = "#fff"
    for (const item of this.items) {
      this.ctx.beginPath()
      this.ctx.arc(
        minimapX + item.position.x * minimapScale,
        minimapY + item.position.y * minimapScale,
        2,
        0,
        Math.PI * 2,
      )
      this.ctx.fill()
    }

    // Draw viewport rectangle on minimap
    this.ctx.strokeStyle = "#fff"
    this.ctx.lineWidth = 1
    this.ctx.strokeRect(
      minimapX + this.camera.x * minimapScale,
      minimapY + this.camera.y * minimapScale,
      this.canvas.width * minimapScale,
      this.canvas.height * minimapScale,
    )
  }

  drawPlayerStats(): void {
    // Draw player health
    this.ctx.fillStyle = "#000"
    this.ctx.fillRect(10, 10, 200, 20)
    this.ctx.fillStyle = "#ff4d4d"
    this.ctx.fillRect(10, 10, (this.player.health / 100) * 200, 20)
    this.ctx.strokeStyle = "#fff"
    this.ctx.strokeRect(10, 10, 200, 20)

    // Draw player armor
    if (this.player.armor > 0) {
      this.ctx.fillStyle = "#000"
      this.ctx.fillRect(10, 35, 200, 20)
      this.ctx.fillStyle = "#4d94ff"
      this.ctx.fillRect(10, 35, (this.player.armor / 100) * 200, 20)
      this.ctx.strokeStyle = "#fff"
      this.ctx.strokeRect(10, 35, 200, 20)
    }

    // Draw weapon info
    if (this.player.weapon) {
      this.ctx.fillStyle = "#fff"
      this.ctx.font = "16px Arial"
      this.ctx.fillText(`${this.player.weapon.name}: ${this.player.weapon.ammo}`, 10, 75)
    }

    // Draw players left
    this.ctx.fillStyle = "#fff"
    this.ctx.font = "16px Arial"
    this.ctx.fillText(`Players: ${this.bots.length + 1}`, 10, 95)
  }

  collectItem(item: Item): void {
    switch (item.type) {
      case "health":
        this.player.health = Math.min(100, this.player.health + item.value)
        break
      case "ammo":
        if (this.player.weapon) {
          this.player.weapon.ammo += item.value
        }
        break
      case "armor":
        this.player.armor = Math.min(100, this.player.armor + item.value)
        break
      case "weapon":
        if (item.weaponType) {
          let damage = 10
          let ammo = 30
          let fireRate = 500

          switch (item.weaponType) {
            case "Pistol":
              damage = 10
              ammo = 30
              fireRate = 500
              break
            case "Shotgun":
              damage = 25
              ammo = 15
              fireRate = 800
              break
            case "Rifle":
              damage = 15
              ammo = 45
              fireRate = 300
              break
            case "Sniper":
              damage = 50
              ammo = 10
              fireRate = 1000
              break
          }

          this.player.weapon = new Weapon(item.weaponType, damage, ammo, fireRate)
        }
        break
    }
  }

  getDistanceToPlayer(entity: Entity): number {
    return entity.position.subtract(this.player.position).length()
  }

  gameOver(isWin: boolean): void {
    this.isGameOver = true

    // Draw game over screen
    this.ctx.fillStyle = "rgba(0, 0, 0, 0.7)"
    this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height)

    this.ctx.fillStyle = isWin ? "#4CAF50" : "#F44336"
    this.ctx.font = "48px Arial"
    this.ctx.textAlign = "center"
    this.ctx.fillText(isWin ? "VICTORY ROYALE!" : "GAME OVER", this.canvas.width / 2, this.canvas.height / 2 - 50)

    this.ctx.fillStyle = "#fff"
    this.ctx.font = "24px Arial"
    this.ctx.fillText("Refresh the page to play again", this.canvas.width / 2, this.canvas.height / 2 + 50)
  }

  handleKeyDown = (e: KeyboardEvent): void => {
    this.keys[e.key] = true
  }

  handleKeyUp = (e: KeyboardEvent): void => {
    this.keys[e.key] = false
  }

  handleMouseMove = (e: MouseEvent): void => {
    const rect = this.canvas.getBoundingClientRect()
    this.mousePosition = new Vector2(e.clientX - rect.left, e.clientY - rect.top)
  }

  handleMouseDown = (e: MouseEvent): void => {
    this.isMouseDown = true
  }

  handleMouseUp = (e: MouseEvent): void => {
    this.isMouseDown = false
  }

  destroy(): void {
    if (this.gameLoop) {
      cancelAnimationFrame(this.gameLoop)
    }

    window.removeEventListener("keydown", this.handleKeyDown)
    window.removeEventListener("keyup", this.handleKeyUp)
    this.canvas.removeEventListener("mousemove", this.handleMouseMove)
    this.canvas.removeEventListener("mousedown", this.handleMouseDown)
    this.canvas.removeEventListener("mouseup", this.handleMouseUp)
  }
}

